#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

#define TAM_PALAVRA 5
#define QTD_PALAVRAS 3

pthread_barrier_t barreira_geracao_letra;
pthread_barrier_t barreira_verifica_pali;

char palavra[TAM_PALAVRA+1];

void* gera_letra(void * p) {
	long id = (long)p;
	int count = 0;

	while (count < QTD_PALAVRAS) {
		time_t t;
		srand(time(&t) + (int) id);
		int num = rand() % 26;
		char letra = 'A' + (char)num;
		palavra[(int)id] = letra;
		sleep(1);
		printf("[%ld] gerou %c...\n", id, letra);
		pthread_barrier_wait(&barreira_geracao_letra);
		pthread_barrier_wait(&barreira_verifica_pali);
		count++;
	}

	return 0;
}

int testa_palindromo(char* str, int tam) {
	int i, j;

	for (i = 0, j = tam-1; i < j; i++, j--) {
		if (str[i] != str[j]) {
//			printf("%c != %c\n", str[i], str[j]);
			return 0;
		}
	}
	return 1;
}

int main(void) {
	pthread_t threads[TAM_PALAVRA];
	int palavra_count = 0;

        pthread_barrier_init(&barreira_geracao_letra, NULL, TAM_PALAVRA + 1);
        pthread_barrier_init(&barreira_verifica_pali, NULL, TAM_PALAVRA + 1);

	for (long i = 0; i < TAM_PALAVRA; i++) {
		pthread_create(&threads[i], NULL, gera_letra, (void*)i);
	}

	while (palavra_count < QTD_PALAVRAS) {
		pthread_barrier_wait(&barreira_geracao_letra);
		palavra[TAM_PALAVRA] = '\0';
		printf("[main] testando se %s é palíndromo...\n", palavra);
		int res = testa_palindromo(palavra, TAM_PALAVRA);
		if (res) {
			printf("[main] %s é um palíndromo!\n", palavra);
		} else {
			printf("[main] %s não é um palíndromo!\n", palavra);
		}
		palavra_count++;
		pthread_barrier_wait(&barreira_verifica_pali);
	}

	return 0;
}
