#include <iostream>
#include <string>
#include <thread>
#include <mutex>
#include <pthread.h>

#define QTD_THREADS 5

pthread_barrier_t barreira_str;

using std::cout;
using std::endl;
using std::string;
using std::thread;

string hash[QTD_THREADS];

class hash_gen {
	int size;
public:
	hash_gen(int s):size(s) { }
	string& get_hash(int pos) {
		const string charset = "abcdefghijklmnopqrstuvwxyz";
		string random_str;
		std::srand(std::time(nullptr));

		for (int i = 0; i < size; ++i) {
			random_str.push_back(charset[std::rand() % charset.length()]);
		}

		hash[pos] = random_str;

		cout << "[" << pos << "] "  << random_str << endl;

		pthread_barrier_wait(&barreira_str);
	}

};

int main(void) {
	thread* threads[QTD_THREADS];

	hash_gen my_hash(6);

	pthread_barrier_init(&barreira_str, NULL, QTD_THREADS + 1);

	for (int i = 0; i < QTD_THREADS; i++) {
		threads[i] = new thread(&hash_gen::get_hash, &my_hash, i);
	}

	pthread_barrier_wait(&barreira_str);
	cout << "Hash gerado: " << endl;
	for (int i = 0; i < QTD_THREADS; i++) {
		cout << hash[i];
	}
	endl;


}
