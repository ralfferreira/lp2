#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <pthread.h>

pthread_cond_t condition = PTHREAD_COND_INITIALIZER;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

int shared_variable = 0;

void* funcao_thread(void* p) {
	long id = (long)p;

	printf("Thread %ld start...\n", id);
        printf("Thread %ld waiting for shared variable change\n", id);

	pthread_mutex_lock(&mutex);

	while (shared_variable <= 5) {
		printf("Thread %ld dentro do while...\n", id);
		pthread_cond_wait(&condition, &mutex);
	}

	printf("Thread %ld: Shared variable = %d\n", id, shared_variable);
	pthread_mutex_unlock(&mutex);

	return NULL;
}

int main(void) {
	pthread_t thread1, thread2;

	pthread_create(&thread1, NULL, funcao_thread, (void*) 1);
	pthread_create(&thread2, NULL, funcao_thread, (void*) 2);

	printf("[main] created threads...\n");


	pthread_mutex_lock(&mutex);

	printf("[main] changing shared variable value...\n");

	sleep(5);

	shared_variable = 6;

	sleep(5);

	pthread_cond_broadcast(&condition);

	sleep(5);

	pthread_mutex_unlock(&mutex);

	sleep(5);

	pthread_join(thread1, NULL);
	pthread_join(thread2, NULL);

	return 0;
}
