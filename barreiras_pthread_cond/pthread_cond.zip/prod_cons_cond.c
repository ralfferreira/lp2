#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
#include <pthread.h>

#define BUFFER_SIZE 5

pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t buffer_full = PTHREAD_COND_INITIALIZER;
pthread_cond_t buffer_empty = PTHREAD_COND_INITIALIZER;

int buffer[BUFFER_SIZE];
int insert_idx = 0;
int remove_idx = 0;

void* producer(void* p) {
	int msg = 1;
	while (1) {
		pthread_mutex_lock(&mutex);
		while( ((insert_idx + 1) % BUFFER_SIZE) == remove_idx) {
			pthread_cond_wait(&buffer_full, &mutex);
		}

		printf("Mensagem enviada: %d\n", msg);
		sleep(1);
		buffer[insert_idx] = msg++;
		insert_idx = (insert_idx + 1) % BUFFER_SIZE;
		pthread_cond_signal(&buffer_empty);
		pthread_mutex_unlock(&mutex);
	}

	return NULL;
}

void* consumer(void* p) {
	while (1) {
		pthread_mutex_lock(&mutex);
		while (insert_idx == remove_idx) {
			pthread_cond_wait(&buffer_empty, &mutex);
		}

		int msg = buffer[remove_idx];
		printf("Mensagem recebida: %d\n", msg);
		sleep(1);
		remove_idx = (remove_idx + 1) % BUFFER_SIZE;
		pthread_cond_signal(&buffer_full);
		pthread_mutex_unlock(&mutex);
	}

	return NULL;
}

int main(void) {
	pthread_t prod, cons;

	pthread_create(&prod, NULL, producer, NULL);
	pthread_create(&cons, NULL, consumer, NULL);

	pthread_join(prod, NULL);
	pthread_join(cons, NULL);

	return 0;

}

